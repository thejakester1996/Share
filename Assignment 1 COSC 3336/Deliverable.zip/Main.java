
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

class proc {

    public int PID;
    public proc next = null;
    public proc prev = null;
    public String state;
    public requests link = null;
};

class requests {

    public String name;
    public int time_value;
    public char iOrN;
    public requests next = null;
    public requests prev = null;
    public proc process = null;
    public requests nextQ = null;
}

public class Main {

    static int cores;
    static int ssdAccesses = 0;
    static int ssdSum = 0;
    static int coreSum = 0;
    static requests[] coreInstructions;
    static int[] coreT;
    static requests TTY;
    static int TTYtime = -1;
    static requests SSD = null;
    static int ssdTime = -1;
    static int processes = 0;
    static int currTime = 0;

    static requests headReq = new requests();
    static requests currentReq = headReq;
    static proc headProcess = new proc();
    static proc currentProcess = headProcess;

    static requests nextNonReady = new requests();
    static requests NonReadyQ = nextNonReady;
    static requests nextInReady = new requests();
    static requests InReadyQ = nextInReady;
    static requests nextTTY = new requests();
    static requests TTYQ = nextTTY;
    static requests nextSSD = new requests();
    static requests ssdQ = nextSSD;

    static String corecore = "CORE";
    static String ssdssd = "SSD";
    static String TTYTTY = "TTY";
    static Scanner in = new Scanner(System.in);

    public static void main(String args[]) {
        try {
            String fileName = "";
            int choice = -1;
            if (args.length > 0) {
                fileName = args[0];
            } else {
                System.out.println("Enter 1 if you want to enter commands manually ");
                System.out.println("Enter 2 if you want to read commands file ");
                System.out.print("Enter 1 or 2: ");
                choice = in.nextInt();
                while (choice != 1 && choice != 2) {
                    System.out.print("Enter 1 or 2: ");
                    choice = in.nextInt();
                }
                if (choice == 2) {
                    System.out.print("Enter file name: ");
                    fileName = in.next();
                }
            }
            BufferedReader reader = null;
            String input = "", line = "";
            String[] words = null;
            if (!fileName.isEmpty()) {
                reader = new BufferedReader(new FileReader(fileName));
            }
            if (choice == 1) {
                System.out.print("cores (int): ");
                cores = in.nextInt();
            } else {
                line = reader.readLine();
                words = line.split("\\s+");
                cores = Integer.parseInt(words[1]);
            }


            coreInstructions = new requests[cores];
            coreT = new int[cores];

            for (int i = 0; i < cores; i++) {
                coreInstructions[i] = null;
                coreT[i] = -1;
            }
            if (choice == 1) {
                System.out.print("command: ");
                input = in.next();
            } else {
                line = reader.readLine();
                words = line.split("\\s+");
                input = words[0];
            }
            while (!input.equals("END")) {
                requests newReq = new requests();
                newReq.name = input;
                if (input.equals("START")) {
                    if (choice == 1) {
                        System.out.print("newReq.time_value (int): ");
                        newReq.time_value = in.nextInt();
                    } else {
                        newReq.time_value = Integer.parseInt(words[1]);
                    }
                    int inputINT;
                    if (choice == 1) {
                        System.out.print("newProc.PID (int): ");
                        inputINT = in.nextInt();
                    } else {
                        line = reader.readLine();
                        words = line.split("\\s+");
                        inputINT = Integer.parseInt(words[1]);
                    }
                    proc newProc = new proc();
                    newProc.PID = inputINT;
                    newProc.state = "READY";
                    processes++;
                    newProc.link = newReq;
                    newProc.prev = currentProcess;
                    currentProcess.next = newProc;
                    currentProcess = currentProcess.next;
                    newReq.iOrN = 'n';
                    newReq.process = currentProcess;
                    newReq.prev = currentReq;
                    currentReq.next = newReq;
                    currentReq = currentReq.next;
                } else {
                    if (choice == 1) {
                        System.out.print("newReq.time_value (int): ");
                        newReq.time_value = in.nextInt();
                    } else {
                        newReq.time_value = Integer.parseInt(words[1]);
                    }
                    newReq.iOrN = 'n';
                    newReq.process = currentProcess;
                    newReq.prev = currentReq;
                    currentReq.next = newReq;
                    currentReq = currentReq.next;
                }
                if (choice == 1) {
                    System.out.print("command: ");
                    input = in.next();
                } else {
                    line = reader.readLine();
                    words = line.split("\\s+");
                    input = words[0];
                }
            }

            readProc(headProcess.next);
            printSummary();
            if (choice == 2) {
                reader.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void readInstruct(requests xrequests) {
        if (xrequests.name.indexOf(corecore) != -1) {
            coreSum += xrequests.time_value;
            boolean full = true;
            for (int i = 0; i < cores; i++) {
                if (coreInstructions[i] == null) {
                    full = false;
                    xrequests.process.state = "RUNNING";
                    coreInstructions[i] = xrequests;
                    coreT[i] = xrequests.time_value + currTime;
                    break;
                }
            }
            if (full == true) {
                xrequests.process.state = "READY";
                if (xrequests.iOrN == 'n') {
                    NonReadyQ.nextQ = xrequests;
                    NonReadyQ = NonReadyQ.nextQ;
                } else if (xrequests.iOrN == 'i') {
                    InReadyQ.nextQ = xrequests;
                    InReadyQ = InReadyQ.nextQ;
                }
            }
        } else if (xrequests.name.indexOf(TTYTTY) != -1) {
            xrequests.process.state = "BLOCKED";
            if (TTY == null) {
                TTY = xrequests;
                TTYtime = xrequests.time_value + currTime;
                xrequests.iOrN = 'i';
            } else {
                TTYQ.nextQ = xrequests;
                TTYQ = TTYQ.nextQ;
                xrequests.iOrN = 'i';
            }
        } else if (xrequests.name.indexOf(ssdssd) != -1) {
            ssdAccesses++;
            ssdSum += xrequests.time_value;
            if (SSD == null) {
                xrequests.process.state = "RUNNING";
                SSD = xrequests;
                ssdTime = xrequests.time_value + currTime;
                xrequests.iOrN = 'i';
            } else {
                xrequests.process.state = "READY";
                ssdQ.nextQ = xrequests;
                ssdQ = ssdQ.nextQ;
                xrequests.iOrN = 'i';
            }
        }
    }

    static void readProc(proc xprocess) {
        update(xprocess.link.time_value);
        System.out.println("Process " + xprocess.PID + " starts at time " + currTime + " ms \n");
        printStatus();
        readInstruct(xprocess.link.next);

        if (xprocess.next != null) {
            readProc(xprocess.next);
        } else {
            update(Integer.MAX_VALUE);
        }
    }

    static void update(int times) {
        int maxTime = -1;
        requests maxInstruction = null;
        for (int i = 0; i < cores; i++) {
            if (coreT[i] < times) {
                if (coreT[i] > maxTime) {
                    maxTime = coreT[i];
                    maxInstruction = coreInstructions[i];
                }
            }
        }
        if (TTYtime < times) {
            if (TTYtime > maxTime) {
                maxTime = TTYtime;
                maxInstruction = TTY;
            }
        }
        if (ssdTime < times) {
            if (ssdTime > maxTime) {
                maxTime = ssdTime;
                maxInstruction = SSD;
            }
        }
        if (maxTime != -1) {
            if (maxInstruction.name.indexOf(corecore) != -1) {
                for (int i = 0; i < cores; i++) {
                    if (coreInstructions[i] == maxInstruction) {
                        update(coreT[i]);
                        requests temp = coreInstructions[i];
                        coreInstructions[i] = null;
                        coreT[i] = -1;
                        if (nextInReady.nextQ != null) {
                            coreInstructions[i] = nextInReady.nextQ;
                            coreT[i] = coreInstructions[i].time_value + currTime;
                            coreInstructions[i].process.state = "RUNNING";
                            nextInReady = nextInReady.nextQ;
                        } else if (nextNonReady.nextQ != null) {
                            coreInstructions[i] = nextNonReady.nextQ;
                            coreT[i] = coreInstructions[i].time_value + currTime;
                            coreInstructions[i].process.state = "RUNNING";
                            nextNonReady = nextNonReady.nextQ;
                        }
                        if (temp.next != null) {
                            if (temp.next.name.equals("START")) {
                                endProc(temp.process);
                            } else {
                                readInstruct(temp.next);
                            }
                        } else {
                            endProc(temp.process);
                        }
                        break;
                    }
                }
            } else if (maxInstruction.name.indexOf(TTYTTY) != -1) {
                update(TTYtime);
                requests temp = TTY;
                TTY = null;
                TTYtime = -1;
                if (nextTTY.nextQ != null) {
                    TTY = nextTTY.nextQ;
                    TTYtime = TTY.time_value + currTime;
                    TTY.process.state = "BLOCKED";
                    nextTTY = nextTTY.nextQ;
                }
                if (temp.next != null) {
                    if (temp.next.name.equals("START")) {
                        endProc(temp.process);
                    } else {
                        readInstruct(temp.next);
                    }
                } else {
                    endProc(temp.process);
                }
            } else if (maxInstruction.name.indexOf(ssdssd) != -1) {
                update(ssdTime);
                requests temp = SSD;
                SSD = null;
                ssdTime = -1;
                if (nextSSD.nextQ != null) {
                    SSD = nextSSD.nextQ;
                    ssdTime = SSD.time_value + currTime;
                    SSD.process.state = "BLOCKED";
                    nextSSD = nextSSD.nextQ;
                }
                if (temp.next != null) {
                    if ((temp.next.name).equals("START")) {
                        endProc(temp.process);
                    } else {
                        readInstruct(temp.next);
                    }
                } else {
                    endProc(temp.process);
                }
            }
            update(times);
        }
        if (times != Integer.MAX_VALUE) {
            currTime = times;
        }
    }

    static void endProc(proc toTerminate) {
        toTerminate.state = "TERMINATED";
        System.out.println("Process " + toTerminate.PID + " terminates at time " + currTime + " ms \n");
        printStatus();
        toTerminate.state = "";
    }

    static void printStatus() {
        proc temp = headProcess;
        while (temp.next != null) {
            temp = temp.next;
            if (temp.state != "") {
                System.out.println("Process " + temp.PID + " is " + temp.state + "\n");
            }
        }
        System.out.println("\n");
    }

    static void printSummary() {
        System.out.println("SUMMARY:\n");
        System.out.println("Total elapsed times: " + currTime + " ms" + "\n");
        System.out.println("Number of processes that completed: " + processes + "\n");
        System.out.println("Total number of SSD accesses: " + ssdAccesses + "\n");
        if (coreSum == 0) {
            System.out.println("Average number of busy cores: 0 ms" + "\n");
        } else {
            System.out.println("Average number of busy cores: " + String.format("%.2f", ((double) coreSum / currTime)) + "\n");
        }
        if (currTime == 0) {
            System.out.println("SSD utilization: 0 percent" + "\n");
        } else {
            System.out.println("SSD utilization: " + String.format("%.2f", ((double) ssdSum / currTime)) + "\n");
        }
    }
}
